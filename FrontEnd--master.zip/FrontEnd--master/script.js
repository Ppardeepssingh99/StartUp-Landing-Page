
// var remClassId = doccument.getElementById('remove');
// function removeClass(){

// 	remClassId.removeClass('dropright');
// }